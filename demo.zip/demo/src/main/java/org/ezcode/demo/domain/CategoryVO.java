package org.ezcode.demo.domain;

import lombok.Data;

/**
 * CategoryVO
 */
@Data
public class CategoryVO {

    private Integer ctno;
	private String ctname;
}